// frontend/js/volunteer-hamburger.js
// Mobile nav drawer for volunteer pages. Include AFTER auth.js.

(function () {
  const drawer = document.createElement('div');
  drawer.className = 'nav-drawer';
  drawer.id = 'navDrawer';
  drawer.innerHTML = `
    <div class="nav-drawer-user">
      <div>
        <div class="nav-drawer-name" id="drawerName">–</div>
        <span class="nav-role-badge role-volunteer" style="font-size:0.7rem;padding:2px 8px;">Volunteer</span>
      </div>
    </div>
    <a href="dashboard"   class="nav-drawer-link" data-page="dashboard">Dashboard</a>
    <a href="scanner"     class="nav-drawer-link" data-page="scanner">Scanner</a>
    <a href="checkin-log" class="nav-drawer-link" data-page="checkin-log">Check-in Log</a>
    <button class="nav-drawer-logout" id="drawerLogout">Sign out</button>
  `;
  document.body.appendChild(drawer);

  const navInner = document.querySelector('.nav-inner');
  const burger = document.createElement('button');
  burger.className = 'nav-hamburger';
  burger.id = 'navBurger';
  burger.setAttribute('aria-label', 'Toggle menu');
  burger.innerHTML = '<span></span><span></span><span></span>';
  navInner.appendChild(burger);

  const page = location.pathname.split('/').pop().replace('', '');
  drawer.querySelectorAll('.nav-drawer-link').forEach(a => {
    if (a.dataset.page === page) a.classList.add('active');
  });

  burger.addEventListener('click', () => {
    burger.classList.toggle('open');
    drawer.classList.toggle('open');
  });

  document.addEventListener('click', e => {
    if (!burger.contains(e.target) && !drawer.contains(e.target)) {
      burger.classList.remove('open');
      drawer.classList.remove('open');
    }
  });

  function fillName() {
    try {
      const raw = sessionStorage.getItem('user');
      if (!raw) return;
      const u = JSON.parse(raw);
      const name = u.full_name || u.name || u.email || '–';
      const el = document.getElementById('drawerName');
      if (el) el.textContent = name;
      const navName = document.getElementById('navName');
      if (navName) navName.textContent = name;
    } catch (_) { }
  }
  fillName();
  setTimeout(fillName, 400);

  function doLogout() {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('user');
    window.location.href = '../login';
  }

  document.getElementById('drawerLogout').addEventListener('click', doLogout);
  const desktopLogout = document.getElementById('logoutBtn');
  if (desktopLogout) desktopLogout.addEventListener('click', doLogout);
})();